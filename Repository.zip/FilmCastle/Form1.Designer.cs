﻿namespace FilmCastle
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button = new System.Windows.Forms.Button();
            this.Material = new System.Windows.Forms.TextBox();
            this.Staff = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Invest = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Eqip = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Ad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.License = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Spends = new System.Windows.Forms.TabPage();
            this.Investments = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.Recruit = new System.Windows.Forms.TextBox();
            this.PR = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.App = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Web = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.Spends.SuspendLayout();
            this.Investments.SuspendLayout();
            this.PR.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(5, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Materials: ";
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(500, 319);
            this.button.Margin = new System.Windows.Forms.Padding(2);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(98, 46);
            this.button.TabIndex = 2;
            this.button.Text = "Calculate";
            this.button.UseVisualStyleBackColor = true;
            this.button.Click += new System.EventHandler(this.button_Click);
            // 
            // Material
            // 
            this.Material.Location = new System.Drawing.Point(80, 3);
            this.Material.Margin = new System.Windows.Forms.Padding(2);
            this.Material.Name = "Material";
            this.Material.Size = new System.Drawing.Size(76, 20);
            this.Material.TabIndex = 3;
            // 
            // Staff
            // 
            this.Staff.Location = new System.Drawing.Point(73, 68);
            this.Staff.Margin = new System.Windows.Forms.Padding(2);
            this.Staff.Name = "Staff";
            this.Staff.Size = new System.Drawing.Size(76, 20);
            this.Staff.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(5, 68);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Staff:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Invest
            // 
            this.Invest.Location = new System.Drawing.Point(96, 14);
            this.Invest.Margin = new System.Windows.Forms.Padding(2);
            this.Invest.Name = "Invest";
            this.Invest.Size = new System.Drawing.Size(76, 20);
            this.Invest.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(5, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Investments:";
            // 
            // Eqip
            // 
            this.Eqip.Location = new System.Drawing.Point(80, 36);
            this.Eqip.Margin = new System.Windows.Forms.Padding(2);
            this.Eqip.Name = "Eqip";
            this.Eqip.Size = new System.Drawing.Size(76, 20);
            this.Eqip.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(5, 36);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Eqipment:";
            // 
            // Ad
            // 
            this.Ad.Location = new System.Drawing.Point(72, 39);
            this.Ad.Margin = new System.Windows.Forms.Padding(2);
            this.Ad.Name = "Ad";
            this.Ad.Size = new System.Drawing.Size(76, 20);
            this.Ad.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(4, 39);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Ads cost:";
            // 
            // License
            // 
            this.License.Location = new System.Drawing.Point(70, 101);
            this.License.Margin = new System.Windows.Forms.Padding(2);
            this.License.Name = "License";
            this.License.Size = new System.Drawing.Size(76, 20);
            this.License.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(5, 101);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "License:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Spends);
            this.tabControl1.Controls.Add(this.Investments);
            this.tabControl1.Controls.Add(this.PR);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(496, 368);
            this.tabControl1.TabIndex = 14;
            // 
            // Spends
            // 
            this.Spends.Controls.Add(this.label1);
            this.Spends.Controls.Add(this.License);
            this.Spends.Controls.Add(this.Material);
            this.Spends.Controls.Add(this.label6);
            this.Spends.Controls.Add(this.label4);
            this.Spends.Controls.Add(this.Eqip);
            this.Spends.Controls.Add(this.label2);
            this.Spends.Controls.Add(this.Staff);
            this.Spends.Location = new System.Drawing.Point(4, 22);
            this.Spends.Name = "Spends";
            this.Spends.Padding = new System.Windows.Forms.Padding(3);
            this.Spends.Size = new System.Drawing.Size(488, 342);
            this.Spends.TabIndex = 0;
            this.Spends.Text = "Spends";
            this.Spends.UseVisualStyleBackColor = true;
            // 
            // Investments
            // 
            this.Investments.Controls.Add(this.label11);
            this.Investments.Controls.Add(this.Recruit);
            this.Investments.Controls.Add(this.label3);
            this.Investments.Controls.Add(this.Invest);
            this.Investments.Location = new System.Drawing.Point(4, 22);
            this.Investments.Name = "Investments";
            this.Investments.Padding = new System.Windows.Forms.Padding(3);
            this.Investments.Size = new System.Drawing.Size(488, 342);
            this.Investments.TabIndex = 1;
            this.Investments.Text = "Investments";
            this.Investments.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(5, 41);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 17);
            this.label11.TabIndex = 8;
            this.label11.Text = "Recruitment:";
            // 
            // Recruit
            // 
            this.Recruit.Location = new System.Drawing.Point(96, 41);
            this.Recruit.Margin = new System.Windows.Forms.Padding(2);
            this.Recruit.Name = "Recruit";
            this.Recruit.Size = new System.Drawing.Size(76, 20);
            this.Recruit.TabIndex = 9;
            // 
            // PR
            // 
            this.PR.Controls.Add(this.label10);
            this.PR.Controls.Add(this.Logo);
            this.PR.Controls.Add(this.label9);
            this.PR.Controls.Add(this.Data);
            this.PR.Controls.Add(this.label8);
            this.PR.Controls.Add(this.App);
            this.PR.Controls.Add(this.label7);
            this.PR.Controls.Add(this.Web);
            this.PR.Controls.Add(this.label5);
            this.PR.Controls.Add(this.Ad);
            this.PR.Location = new System.Drawing.Point(4, 22);
            this.PR.Name = "PR";
            this.PR.Size = new System.Drawing.Size(488, 342);
            this.PR.TabIndex = 2;
            this.PR.Text = "PR";
            this.PR.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(4, 9);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 17);
            this.label10.TabIndex = 16;
            this.label10.Text = "Custom logo:";
            // 
            // Logo
            // 
            this.Logo.Location = new System.Drawing.Point(98, 9);
            this.Logo.Margin = new System.Windows.Forms.Padding(2);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(76, 20);
            this.Logo.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(7, 134);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 17);
            this.label9.TabIndex = 14;
            this.label9.Text = "Database:";
            // 
            // Data
            // 
            this.Data.Location = new System.Drawing.Point(92, 134);
            this.Data.Margin = new System.Windows.Forms.Padding(2);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(76, 20);
            this.Data.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(7, 102);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "Mobile app:";
            // 
            // App
            // 
            this.App.Location = new System.Drawing.Point(92, 102);
            this.App.Margin = new System.Windows.Forms.Padding(2);
            this.App.Name = "App";
            this.App.Size = new System.Drawing.Size(76, 20);
            this.App.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.20895F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(7, 71);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Website:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Web
            // 
            this.Web.Location = new System.Drawing.Point(75, 71);
            this.Web.Margin = new System.Windows.Forms.Padding(2);
            this.Web.Name = "Web";
            this.Web.Size = new System.Drawing.Size(76, 20);
            this.Web.TabIndex = 11;
            this.Web.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Expense";
            this.tabControl1.ResumeLayout(false);
            this.Spends.ResumeLayout(false);
            this.Spends.PerformLayout();
            this.Investments.ResumeLayout(false);
            this.Investments.PerformLayout();
            this.PR.ResumeLayout(false);
            this.PR.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.TextBox Material;
        private System.Windows.Forms.TextBox Staff;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Invest;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Eqip;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Ad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox License;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Spends;
        private System.Windows.Forms.TabPage Investments;
        private System.Windows.Forms.TabPage PR;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Web;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox App;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Recruit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Logo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Data;
    }
}

