﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilmCastle
{


    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            Profit newForm = new Profit();
            newForm.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
    public class Calculations
    {
        int Earnings;
        int Spends;
        int Profit;

    }
}
